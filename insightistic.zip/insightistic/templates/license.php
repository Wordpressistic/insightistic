<?php
/**
 * License / SaaS connection template.
 *
 * @package Insightistic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$isp_connected = Insightistic_License_Manager::is_connected();
$isp_state     = Insightistic_License_Manager::state();
$isp_status    = Insightistic_License_Manager::status();
$isp_stale     = Insightistic_License_Manager::is_stale();
$isp_last4     = get_option( 'insightistic_license_last4', '' );
$isp_grace     = Insightistic_Feature_Gate::in_legacy_grace();
$isp_app_url   = 'https://app.insightistic.com';

$isp_status_labels = array(
	'none'           => __( 'Not connected', 'insightistic' ),
	'active'         => __( 'Active', 'insightistic' ),
	'trialing'       => __( 'Trial', 'insightistic' ),
	'expired'        => __( 'Trial expired', 'insightistic' ),
	'cancelled'      => __( 'Cancelled', 'insightistic' ),
	'suspended'      => __( 'Suspended', 'insightistic' ),
	'payment_failed' => __( 'Payment issue', 'insightistic' ),
	'revoked'        => __( 'Revoked', 'insightistic' ),
);
$isp_status_class  = in_array( $isp_status, array( 'active', 'trialing' ), true ) && ! $isp_stale
	? 'isp-license-status-good'
	: ( 'none' === $isp_status ? 'isp-license-status-neutral' : 'isp-license-status-bad' );

$isp_features_meta   = array(
	'basic_analytics'        => array( __( 'Basic analytics', 'insightistic' ), __( 'GA4, Search Console & PageSpeed dashboards', 'insightistic' ) ),
	'woocommerce_analytics'  => array( __( 'WooCommerce Intelligence', 'insightistic' ), __( 'Revenue, products, categories & customers', 'insightistic' ) ),
	'seo_analysis'           => array( __( 'SEO Analysis', 'insightistic' ), __( 'Ranking gaps & content opportunities', 'insightistic' ) ),
	'email_audit_automation' => array( __( 'Email Audit Automation', 'insightistic' ), __( 'Scheduled branded audit digests', 'insightistic' ) ),
	'ai_insights'            => array( __( 'AI Business Insights', 'insightistic' ), __( 'Expert AI analysis of your data', 'insightistic' ) ),
	'advanced_reports'       => array( __( 'Advanced Reports', 'insightistic' ), __( 'Anomaly alerts & content lab', 'insightistic' ) ),
	'scheduled_reports'      => array( __( 'Scheduled Reports', 'insightistic' ), __( 'Weekly & monthly cloud reports', 'insightistic' ) ),
	'multi_site'             => array( __( 'Multi-site', 'insightistic' ), __( 'Manage several websites from one account', 'insightistic' ) ),
	'agency_white_label'     => array( __( 'White-label', 'insightistic' ), __( 'Client-branded reports', 'insightistic' ) ),
	'team_access'            => array( __( 'Team Access', 'insightistic' ), __( 'Invite teammates & clients', 'insightistic' ) ),
);
$isp_active_features = Insightistic_License_Manager::features();
?>
<div class="wrap isp-wrap isp-license-wrap">

	<div class="isp-header">
		<div class="isp-header-brand">
			<div>
				<h1 class="isp-header-title"><?php esc_html_e( 'License & Connection', 'insightistic' ); ?></h1>
				<p class="isp-header-sub"><?php esc_html_e( 'One key connects this site to your Insightistic account — analytics cloud, automations and AI.', 'insightistic' ); ?></p>
			</div>
		</div>
		<div class="isp-header-actions">
			<span class="isp-license-status <?php echo esc_attr( $isp_status_class ); ?>">
				<span class="isp-license-status-dot"></span>
				<?php echo esc_html( $isp_status_labels[ $isp_status ] ?? $isp_status ); ?>
				<?php if ( $isp_stale ) : ?>
					· <?php esc_html_e( 'reconnecting…', 'insightistic' ); ?>
				<?php endif; ?>
			</span>
		</div>
	</div>

	<?php if ( $isp_grace && ! $isp_connected ) : ?>
		<div class="isp-license-banner isp-license-banner-grace">
			<strong><?php esc_html_e( 'Upgrade grace period active.', 'insightistic' ); ?></strong>
			<?php
			printf(
				/* translators: %s: formatted date */
				esc_html__( 'Your existing add-ons keep working until %s. Connect your free Insightistic account to keep them active after that.', 'insightistic' ),
				esc_html( date_i18n( get_option( 'date_format' ), (int) get_option( 'insightistic_legacy_grace_until', 0 ) ) )
			);
			?>
		</div>
	<?php endif; ?>

	<div id="isp-license-msg" class="isp-license-msg" style="display:none;" role="status"></div>

	<?php if ( ! $isp_connected ) : ?>

		<div class="isp-license-grid">
			<div class="isp-license-card isp-license-card-main isp-animate-in">
				<h2 class="isp-license-card-title"><?php esc_html_e( 'Activate your license', 'insightistic' ); ?></h2>
				<p class="isp-license-card-sub">
					<?php esc_html_e( 'Paste the license key from your Insightistic dashboard. Basic analytics stay free forever — the key unlocks the advanced modules and cloud sync.', 'insightistic' ); ?>
				</p>

				<div class="isp-license-form">
					<label class="screen-reader-text" for="isp-license-key"><?php esc_html_e( 'License key', 'insightistic' ); ?></label>
					<input
						type="text"
						id="isp-license-key"
						class="isp-input isp-license-input"
						placeholder="insightistic_xxxxxxxxxxxxxxxxxxxxxxxxxx"
						autocomplete="off"
						spellcheck="false"
					/>
					<button type="button" class="isp-btn isp-btn-primary isp-license-activate-btn" id="isp-license-activate">
						<span class="isp-btn-text"><?php esc_html_e( 'Activate', 'insightistic' ); ?></span>
					</button>
				</div>
				<p class="isp-license-form-hint">
					<?php esc_html_e( 'The key is exchanged for secure site credentials and never stored on this server.', 'insightistic' ); ?>
				</p>

				<div class="isp-license-steps">
					<h3><?php esc_html_e( 'Don’t have a key yet?', 'insightistic' ); ?></h3>
					<ol>
						<li>
							<?php
							printf(
								/* translators: %s: link to app */
								esc_html__( 'Create a free account at %s — includes a 7-day trial of every advanced feature, no card required.', 'insightistic' ),
								'<a href="' . esc_url( $isp_app_url . '/register?ref=plugin' ) . '" target="_blank" rel="noopener">app.insightistic.com</a>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Copy the license key shown after signup (also in Dashboard → Licenses).', 'insightistic' ); ?></li>
						<li><?php esc_html_e( 'Paste it above and click Activate. This site appears in your dashboard automatically.', 'insightistic' ); ?></li>
					</ol>
					<a class="isp-btn isp-btn-ghost" href="<?php echo esc_url( $isp_app_url . '/register?ref=plugin' ); ?>" target="_blank" rel="noopener">
						<?php esc_html_e( 'Start 7-day free trial →', 'insightistic' ); ?>
					</a>
				</div>
			</div>

			<div class="isp-license-card isp-animate-in isp-animate-delay-1">
				<h2 class="isp-license-card-title"><?php esc_html_e( 'What a license unlocks', 'insightistic' ); ?></h2>
				<ul class="isp-license-features">
					<?php foreach ( $isp_features_meta as $isp_slug => $isp_meta ) : ?>
						<?php
						if ( 'basic_analytics' === $isp_slug ) {
							continue; }
						?>
						<li class="isp-license-feature isp-license-feature-locked">
							<span class="isp-license-feature-icon" aria-hidden="true">
								<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
							</span>
							<span>
								<strong><?php echo esc_html( $isp_meta[0] ); ?></strong>
								<em><?php echo esc_html( $isp_meta[1] ); ?></em>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>

	<?php else : ?>

		<div class="isp-license-grid">
			<div class="isp-license-card isp-license-card-main isp-animate-in">
				<h2 class="isp-license-card-title"><?php esc_html_e( 'Connection', 'insightistic' ); ?></h2>

				<div class="isp-license-keyline">
					<code class="isp-license-masked">insightistic_ ••••••••••••••••••••<?php echo esc_html( $isp_last4 ); ?></code>
					<?php if ( ! empty( $isp_state['plan_name'] ) ) : ?>
						<span class="isp-license-plan-badge"><?php echo esc_html( $isp_state['plan_name'] ); ?></span>
					<?php endif; ?>
				</div>

				<dl class="isp-license-meta">
					<?php if ( 'trialing' === $isp_status && ! empty( $isp_state['trial_ends_at'] ) ) : ?>
						<div>
							<dt><?php esc_html_e( 'Trial ends', 'insightistic' ); ?></dt>
							<dd><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $isp_state['trial_ends_at'] ) ) ); ?></dd>
						</div>
					<?php endif; ?>
					<div>
						<dt><?php esc_html_e( 'Websites on your plan', 'insightistic' ); ?></dt>
						<dd><?php echo esc_html( (int) ( $isp_state['activations_used'] ?? 1 ) . ' / ' . (int) ( $isp_state['activation_limit'] ?? 1 ) ); ?></dd>
					</div>
					<div>
						<dt><?php esc_html_e( 'Last verified', 'insightistic' ); ?></dt>
						<dd>
							<?php
							echo ! empty( $isp_state['validated_at'] )
								? esc_html( human_time_diff( (int) $isp_state['validated_at'] ) . ' ' . __( 'ago', 'insightistic' ) )
								: esc_html__( 'never', 'insightistic' );
							?>
						</dd>
					</div>
				</dl>

				<?php if ( in_array( $isp_status, array( 'expired', 'cancelled', 'suspended', 'payment_failed', 'revoked' ), true ) ) : ?>
					<div class="isp-license-banner isp-license-banner-warn">
						<?php if ( 'expired' === $isp_status ) : ?>
							<?php esc_html_e( 'Your trial has ended — advanced modules are paused, basic analytics keep working. Pick a plan to switch everything back on.', 'insightistic' ); ?>
						<?php elseif ( 'payment_failed' === $isp_status ) : ?>
							<?php esc_html_e( 'There is a billing issue on your account. Features stay active for a few days while payment retries.', 'insightistic' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'This license is not active. Reactivate from your Insightistic dashboard to continue.', 'insightistic' ); ?>
						<?php endif; ?>
						<a href="<?php echo esc_url( $isp_app_url . '/dashboard/billing?ref=plugin' ); ?>" target="_blank" rel="noopener" class="isp-btn isp-btn-primary">
							<?php esc_html_e( 'Open billing →', 'insightistic' ); ?>
						</a>
					</div>
				<?php endif; ?>

				<div class="isp-license-actions">
					<button type="button" class="isp-btn isp-btn-primary" id="isp-license-refresh">
						<span class="isp-btn-text"><?php esc_html_e( 'Refresh License', 'insightistic' ); ?></span>
					</button>
					<a class="isp-btn isp-btn-ghost" href="<?php echo esc_url( $isp_app_url . '/dashboard/licenses?ref=plugin' ); ?>" target="_blank" rel="noopener">
						<?php esc_html_e( 'Manage in dashboard', 'insightistic' ); ?>
					</a>
					<button type="button" class="isp-btn isp-btn-danger-ghost" id="isp-license-disconnect">
						<?php esc_html_e( 'Disconnect site', 'insightistic' ); ?>
					</button>
				</div>
			</div>

			<div class="isp-license-card isp-animate-in isp-animate-delay-1">
				<h2 class="isp-license-card-title"><?php esc_html_e( 'Your features', 'insightistic' ); ?></h2>
				<ul class="isp-license-features">
					<?php foreach ( $isp_features_meta as $isp_slug => $isp_meta ) : ?>
						<?php $isp_on = in_array( $isp_slug, $isp_active_features, true ) || 'basic_analytics' === $isp_slug; ?>
						<li class="isp-license-feature <?php echo $isp_on ? 'isp-license-feature-on' : 'isp-license-feature-locked'; ?>">
							<span class="isp-license-feature-icon" aria-hidden="true">
								<?php if ( $isp_on ) : ?>
									<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
								<?php else : ?>
									<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
								<?php endif; ?>
							</span>
							<span>
								<strong><?php echo esc_html( $isp_meta[0] ); ?></strong>
								<em><?php echo esc_html( $isp_meta[1] ); ?></em>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( count( $isp_active_features ) <= 3 && in_array( $isp_status, array( 'active', 'trialing' ), true ) ) : ?>
					<a class="isp-btn isp-btn-ghost isp-license-upgrade-link" href="<?php echo esc_url( $isp_app_url . '/dashboard/billing?ref=plugin' ); ?>" target="_blank" rel="noopener">
						<?php esc_html_e( 'Unlock more with Growth →', 'insightistic' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>

	<?php endif; ?>

	<p class="isp-footer">
		<?php esc_html_e( 'Basic analytics are free forever. Your Google credentials and settings never leave this site — only aggregated metrics sync to your Insightistic dashboard.', 'insightistic' ); ?>
	</p>
</div>
