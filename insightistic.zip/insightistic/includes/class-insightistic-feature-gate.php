<?php
/**
 * Central feature gate. Every plan-gated module asks this class before doing
 * work — server-side in AJAX handlers, not just in the UI.
 *
 * Free forever (never gated): GA4 / GSC / PageSpeed dashboards, the
 * engagement tracker, basic AI insights, settings, and the license screen.
 *
 * Gated feature slugs (shared vocabulary with the SaaS API and dashboard):
 *   woocommerce_analytics  seo_analysis  email_audit_automation
 *   ai_insights  advanced_reports  scheduled_reports  multi_site
 *   agency_white_label  team_access
 *
 * Legacy grace: installs upgrading from <= 3.3.0 that already used gated
 * add-ons keep them working for 14 days (insightistic_legacy_grace_until),
 * so existing users are never cut off overnight.
 *
 * @package Insightistic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Insightistic_Feature_Gate
 */
class Insightistic_Feature_Gate {

	/**
	 * License statuses under which paid features stay unlocked.
	 *
	 * @var string[]
	 */
	const ENTITLED_STATUSES = array( 'active', 'trialing', 'payment_failed' );

	/**
	 * Add-on slug -> required feature.
	 *
	 * @var array<string,string>
	 */
	const ADDON_FEATURES = array(
		'woocommerce_pro'   => 'woocommerce_analytics',
		'seo_opportunities' => 'seo_analysis',
		'anomaly_alerts'    => 'advanced_reports',
		'content_lab'       => 'advanced_reports',
		'email_automations' => 'email_audit_automation',
	);

	/**
	 * Whether a feature may run right now.
	 *
	 * @param string $feature Feature slug.
	 * @return bool
	 */
	public static function can( $feature ) {
		$feature = sanitize_key( $feature );

		if ( 'basic_analytics' === $feature || '' === $feature ) {
			return true;
		}

		if ( self::in_legacy_grace() ) {
			return true;
		}

		if ( ! Insightistic_License_Manager::is_connected() ) {
			return false;
		}

		$status = Insightistic_License_Manager::status();
		if ( ! in_array( $status, self::ENTITLED_STATUSES, true ) ) {
			return false;
		}

		if ( Insightistic_License_Manager::is_stale() ) {
			return false; // Grace window exhausted with no successful check-in.
		}

		return in_array( $feature, Insightistic_License_Manager::features(), true );
	}

	/**
	 * Why a feature is locked — drives which upgrade prompt the UI shows.
	 *
	 * @param string $feature Feature slug.
	 * @return string ok | no_license | status_<status> | stale | not_in_plan
	 */
	public static function reason( $feature ) {
		if ( self::can( $feature ) ) {
			return 'ok';
		}
		if ( ! Insightistic_License_Manager::is_connected() ) {
			return 'no_license';
		}

		$status = Insightistic_License_Manager::status();
		if ( ! in_array( $status, self::ENTITLED_STATUSES, true ) ) {
			return 'status_' . $status;
		}
		if ( Insightistic_License_Manager::is_stale() ) {
			return 'stale';
		}

		return 'not_in_plan';
	}

	/**
	 * The feature an add-on toggle requires ('' = ungated).
	 *
	 * @param string $addon_slug Add-on slug.
	 * @return string
	 */
	public static function addon_feature( $addon_slug ) {
		return self::ADDON_FEATURES[ sanitize_key( $addon_slug ) ] ?? '';
	}

	/**
	 * Legacy 14-day grace for pre-4.0 installs (set once at upgrade).
	 *
	 * @return bool
	 */
	public static function in_legacy_grace() {
		$until = (int) get_option( 'insightistic_legacy_grace_until', 0 );

		return $until > time();
	}

	/**
	 * Locked-state upgrade card (spec §9). Also used inside AJAX error payloads.
	 *
	 * @param string $feature Feature slug.
	 * @param string $title   Card heading.
	 * @param string $message One-line value statement for this feature.
	 * @return string HTML (escaped).
	 */
	public static function locked_card( $feature, $title = '', $message = '' ) {
		$feature = sanitize_key( $feature );
		$reason  = self::reason( $feature );
		$title   = $title ? $title : __( 'Premium feature', 'insightistic' );

		if ( '' === $message ) {
			$message = __( 'This feature is part of the Insightistic Growth plan.', 'insightistic' );
		}

		switch ( $reason ) {
			case 'no_license':
				$hint = __( 'Connect your Insightistic account to start a free 7-day trial — every advanced feature included.', 'insightistic' );
				$cta  = __( 'Connect your account', 'insightistic' );
				$url  = admin_url( 'admin.php?page=insightistic-license' );
				break;
			case 'status_expired':
				$hint = __( 'Your trial has ended. Your data and settings are safe — pick a plan to switch everything back on.', 'insightistic' );
				$cta  = __( 'Reactivate', 'insightistic' );
				$url  = 'https://app.insightistic.com/dashboard/billing?ref=plugin&feature=' . $feature;
				break;
			case 'status_cancelled':
			case 'status_suspended':
			case 'status_revoked':
				$hint = __( 'Your subscription is not active. Reactivate from your Insightistic dashboard to continue.', 'insightistic' );
				$cta  = __( 'Open dashboard', 'insightistic' );
				$url  = 'https://app.insightistic.com/dashboard/billing?ref=plugin&feature=' . $feature;
				break;
			case 'stale':
				$hint = __( 'We have not been able to reach Insightistic for a while, so advanced features are paused. Click Refresh License once your site is back online.', 'insightistic' );
				$cta  = __( 'Refresh license', 'insightistic' );
				$url  = admin_url( 'admin.php?page=insightistic-license' );
				break;
			default: // not_in_plan
				$hint = __( 'Upgrade your plan to unlock this module. Changes apply to this site automatically.', 'insightistic' );
				$cta  = __( 'View plans', 'insightistic' );
				$url  = 'https://app.insightistic.com/dashboard/billing?ref=plugin&feature=' . $feature;
				break;
		}

		return sprintf(
			'<div class="isp-locked-card" data-feature="%1$s">
				<div class="isp-locked-icon" aria-hidden="true">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
				</div>
				<h3 class="isp-locked-title">%2$s</h3>
				<p class="isp-locked-msg">%3$s</p>
				<p class="isp-locked-hint">%4$s</p>
				<a class="isp-btn isp-btn-primary" href="%5$s"%6$s>%7$s</a>
			</div>',
			esc_attr( $feature ),
			esc_html( $title ),
			esc_html( $message ),
			esc_html( $hint ),
			esc_url( $url ),
			( 0 === strpos( $url, 'http' ) ? ' target="_blank" rel="noopener"' : '' ),
			esc_html( $cta )
		);
	}

	/**
	 * Compact state array for wp_localize_script (drives JS-side lock badges).
	 *
	 * @return array
	 */
	public static function js_state() {
		return array(
			'connected'   => Insightistic_License_Manager::is_connected(),
			'status'      => Insightistic_License_Manager::status(),
			'features'    => Insightistic_License_Manager::features(),
			'stale'       => Insightistic_License_Manager::is_stale(),
			'legacyGrace' => self::in_legacy_grace(),
		);
	}
}
